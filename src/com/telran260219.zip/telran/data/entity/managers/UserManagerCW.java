package com.telran.data.entity.managers;

import com.telran.data.entity.ProfileEntityCW;
import com.telran.data.entity.UserEntityCW;
import com.telran.data.entity.utils.Utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class UserManagerCW {
    private Path rootDir;
    private Path userFile;
    private Path profileFile;

    public UserManagerCW(String rootDir, String userFile, String profileFile) throws IOException {
        this.rootDir = Path.of(rootDir);
        if (!Files.exists(this.rootDir)) {
            Files.createDirectory(this.rootDir);
        } else if (Files.isRegularFile(this.rootDir)) {
            throw new IOException(rootDir + " is a file!");
        }

        this.profileFile = Path.of(this.rootDir.toString(), profileFile);
        if (Files.exists(this.profileFile)) {
            if (Files.isDirectory(this.profileFile)) {
                throw new IOException(profileFile + " is a dir!");
            }
        } else {
            Files.createFile(this.profileFile);
        }

        this.userFile = Path.of(this.rootDir.toString(), userFile);
        if (Files.exists(this.userFile)) {
            if (Files.isDirectory(this.userFile)) {
                throw new IOException(profileFile + " is a dir!");
            }
        } else {
            Files.createFile(this.userFile);
        }
    }

    public boolean addUser(UserEntityCW user) throws IOException {
        Objects.requireNonNull(user);
        Utils.save(userFile, user.toString());
        return true;
    }

    public UserEntityCW getUserByEmail(String email) throws IOException {
        Objects.requireNonNull(email);
        try (Stream<String> stream = Files.lines(userFile)){
            return stream.map(UserEntityCW::fromString).
                    filter(user -> user.getEmail().equals(email)).
                    findFirst().orElse(null);
        }
    }

    public List<UserEntityCW> getAllUsers() throws IOException {
        try (Stream<String> stream = Files.lines(userFile)) {
            return stream.map(UserEntityCW::fromString).collect(Collectors.toList());
        }
    }

    private List<UserEntityCW> getAllUsersWithOutNext(String email) throws IOException {
        try (Stream<String> stream = Files.lines(userFile)) {
            return stream.map(UserEntityCW::fromString).
                    filter(user -> !user.getEmail().equals(email)).
                    collect(Collectors.toList());
        }
    }

    public boolean updateUser(UserEntityCW userEntity) throws IOException {
        Objects.requireNonNull(userEntity);
        List<UserEntityCW> list = getAllUsersWithOutNext(userEntity.getEmail());
        list.add(userEntity);
        Utils.saveAll(userFile, list);
        return true;
    }

    private boolean removeUser(String email) throws IOException {
        Objects.requireNonNull(email);
        List<UserEntityCW> list = getAllUsersWithOutNext(email);
        return Utils.saveAll(userFile, list);
    }

    public boolean addProfile(ProfileEntityCW profile) {
        Objects.requireNonNull(profile);
        Utils.save(profileFile, profile.toString());
        return true;
    }

    public ProfileEntityCW getProfileById(String uuid) throws IOException {
        Objects.requireNonNull(uuid);
        try (Stream<String> stream = Files.lines(profileFile)) {
            return stream.map(ProfileEntityCW::fromString)
                    .filter(profile -> profile.getUuid().equals(uuid))
                    .findFirst().orElse(null);
        }
    }

    private List<ProfileEntityCW> getAllProfilesWithoutNext(String uuid) throws IOException {
        Objects.requireNonNull(uuid);
        try (Stream<String> stream = Files.lines(profileFile)) {
            return stream.map(ProfileEntityCW::fromString)
                    .filter(profile -> profile.getUuid().equals(uuid))
                    .collect(Collectors.toList());
        }
    }

    public boolean updateProfile(ProfileEntityCW profile) throws IOException {
        Objects.requireNonNull(profile);
        List<ProfileEntityCW> profiles = getAllProfilesWithoutNext(profile.getUuid());
        profiles.add(profile);
        return Utils.saveAll(profileFile, profiles);
    }

    public boolean removeProfile(String uuid) throws IOException {
        Objects.requireNonNull(uuid);
        List<ProfileEntityCW> list = getAllProfilesWithoutNext(uuid);
        return Utils.saveAll(profileFile, list);
    }



}
