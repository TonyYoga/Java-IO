package com.telran.data.entity.managers;

import com.telran.data.entity.CategoryEntity;
import com.telran.data.entity.CityEntity;
import com.telran.data.entity.utils.Utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.stream.Collectors;

public class CatalogManager {
    private Path rootDirectory;
    private Path catFile;
    private Path cityFile;

    public CatalogManager(String rootDirectory, String catFileName, String cityFileName) throws IOException {
        this.rootDirectory = Path.of(rootDirectory);
        if (!Files.exists(this.rootDirectory)) {
            Files.createDirectory(this.rootDirectory);
        } else if (Files.isRegularFile(this.rootDirectory)){
            throw new IOException(rootDirectory + "  is a file!");
        }

        catFile = Path.of(this.rootDirectory.toString(), catFileName);
        if (Files.exists(catFile)) {
            if (Files.isDirectory(catFile)) {
                throw new IOException(catFileName + " is directory!");
            }
        } else {
            Files.createFile(catFile);
        }
        cityFile = Path.of(this.rootDirectory.toString(), cityFileName);

        if (Files.exists(cityFile)) {
            if (Files.isDirectory(cityFile)) {
                throw new IOException(cityFileName + " is directory!");
            }
        } else {
            Files.createFile(cityFile);
        }
    }

    public boolean addCity(CityEntity city) throws IOException {
        Objects.requireNonNull(city);
//        try (BufferedWriter bw = Files.newBufferedWriter(cityFile, StandardOpenOption.APPEND)) {
//            if (Files.size(cityFile) > 0) {
//                bw.newLine();
//            }
//            bw.write(city.toString());
//        }
        return Utils.save(cityFile, city.toString());
    }

//    public List<CityEntity> getAllCitiesMy() throws IOException {
//        List<CityEntity> res = new ArrayList<>();
//        String line;
//        try (BufferedReader br = Files.newBufferedReader(cityFile)){
//            while ((line = br.readLine()) != null) {
//                res.add(CityEntity.fromString(line));
//            }
//        }
//        return res;
//    }

//    public boolean removeCityByUuidMY(String uuid) throws IOException {
////        FIXIT do not delete if we have data with this city
//        Objects.requireNonNull(uuid);
//        List<CityEntity> cities = getAllCities();
//        boolean res = cities.remove(CityEntity.fromString(uuid + "," + "temp"));
//        if (res) {
//            stringsToFile(cities.toArray(), cityFile);
//        }
//        return res;
//    }

//    public boolean updateCityMY(String uuid, String newCityName) throws IOException {
//        Objects.requireNonNull(uuid);
//        Objects.requireNonNull(newCityName);
//        boolean res = false;
//        if (newCityName.isEmpty()) {
//            return res;
//        }
//        res = removeCityByUuidMY(uuid);
//        if (res) {
//            addCity(CityEntity.fromString(uuid + "," + newCityName));
//        }
//        return res;
//    }

    public boolean addCategory(String categoryName) throws IOException {
        Objects.requireNonNull(categoryName);
        return addCategory(CategoryEntity.of(categoryName));
    }

    private boolean addCategory(CategoryEntity cat) throws IOException {
        Objects.requireNonNull(cat);
//        try (BufferedWriter bw = Files.newBufferedWriter(catFile, StandardOpenOption.APPEND)) {
//            if (Files.size(catFile) > 0) {
//                bw.newLine();
//            }
//            bw.write(cat.toString());
//        }
        return Utils.save(catFile, cat.toString());
    }

    public List<CategoryEntity> getAllCategories() throws IOException {
        List<CategoryEntity> res = new ArrayList<>();
        String line;
        try (BufferedReader br = Files.newBufferedReader(catFile)){
            while ((line = br.readLine()) != null) {
                res.add(CategoryEntity.fromString(line));
            }
        }
        return res;
    }

    private List<CategoryEntity> getAllCategoriesWithOut(String uuid) throws IOException {
        return Files.lines(catFile).
                map(CategoryEntity::fromString).
                filter(x -> x.getUuid().equals(uuid)).
                collect(Collectors.toList());

    }

    public boolean removeCategoryByUuid(String uuid) {
        try {
            Utils.saveAll(catFile, getAllCategoriesWithOut(uuid));
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean updateCategory(String uuid, String newCategoryName) throws IOException {
        Objects.requireNonNull(uuid);
        Objects.requireNonNull(newCategoryName);
        boolean res = false;
        if (newCategoryName.isEmpty()) {
            return res;
        }
        List<CategoryEntity> catList = getAllCategoriesWithOut(uuid);
//        res = removeCategoryByUuid(uuid);
        catList.add(CategoryEntity.fromString(uuid + "," + newCategoryName));
        return true;
    }

//    private void stringsToFile(Object[] lines, Path file) throws IOException {
//        try (BufferedWriter bw = Files.newBufferedWriter(file)){
//            for (int i = 0; i < lines.length; i++) {
//                bw.write(lines[i].toString());
//                //Don't add newLine at the end of file
//                if(i < lines.length - 1) {
//                    bw.newLine();
//                }
//            }
//        }
//    }

    //Solution from Grigory
//    private boolean sevaAll(Path path, List<?> list) throws IOException {
//        try (BufferedWriter bw = Files.newBufferedWriter(path)) {
//            for (int i = 0; i < list.size(); i++) {
//                bw.write(list.get(i).toString());
//                if (i != list.size() - 1) {
//                    bw.newLine();
//                }
//            }
//        }
//        return true;
//    }

    public List<CityEntity> getAllCities() throws IOException {
        return Files.lines(cityFile)
                .map(CityEntity::fromString)
                .collect(Collectors.toList());
    }

    private List<CityEntity> getAllCitiesWithout(String uuidFilter) throws IOException {
        return Files.lines(cityFile)
                .map(CityEntity::fromString)
                .filter(v -> !uuidFilter.equals(v.getUuid()))
                .collect(Collectors.toList());
    }

    public boolean removeCity(String uuid) {
        try {
            Utils.saveAll(cityFile, getAllCitiesWithout(uuid));
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean updateCity(String uuid, String cityName) throws IOException {
        List<CityEntity> cities = getAllCitiesWithout(uuid);
        cities.add(CityEntity.fromString(uuid + "," + cityName));
        Utils.saveAll(cityFile, cities);
        return true;
    }
}