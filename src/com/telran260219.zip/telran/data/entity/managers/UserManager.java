package com.telran.data.entity.managers;

import com.telran.data.entity.ProfileEntity;
import com.telran.data.entity.Role;
import com.telran.data.entity.UserEntity;
import com.telran.data.entity.utils.Utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

public class UserManager {
    private Path rootDirectory;
    private Path profileFile;
    private Path userFile;

    public UserManager(String rootDirectory, String userFile, String profileFile) throws IOException {
        this.rootDirectory = Path.of(rootDirectory);
        if (!Files.exists(this.rootDirectory)) {
            Files.createDirectory(this.rootDirectory);
        } else if (Files.isRegularFile(this.rootDirectory)) {
            throw new IOException(rootDirectory + " is a file!");
        }

        this.profileFile = Path.of(this.rootDirectory.toString(), profileFile);
        if (Files.exists(this.profileFile)) {
            if (Files.isDirectory(this.profileFile)) {
                throw new IOException(profileFile + " is a dir!");
            }
        } else {
            Files.createFile(this.profileFile);
        }

        this.userFile = Path.of(this.rootDirectory.toString(), userFile);
        if (Files.exists(this.userFile)) {
            if (Files.isDirectory(this.userFile)) {
                throw new IOException(profileFile + " is a dir!");
            }
        } else {
            Files.createFile(this.userFile);
        }
    }
    //CRUD Profiles
    public String addProfile(String name, String lastName, String phone) throws IOException {
        ProfileEntity curr = ProfileEntity.of(name, lastName, phone);
        Utils.save(profileFile, curr.toString());
        return curr.getUuid().toString();
    }

    public boolean addProfile(ProfileEntity profileEntity) {
        Objects.requireNonNull(profileEntity);
        return Utils.save(profileFile, profileEntity.toString());
    }

    public List<ProfileEntity> getAllProfiles() throws IOException {
        return Files.lines(profileFile).
                map(ProfileEntity::fromString).
                collect(Collectors.toList());
    }

    public ProfileEntity getProfileByUuid(String uuid) throws IOException {
        return Files.lines(profileFile).
                map(ProfileEntity::fromString).
                filter(profile -> profile.getUuid().equals(UUID.fromString(uuid))).findAny().orElse(null);
    }

    private List<ProfileEntity> getAllProfileWithOut(String uuid) throws IOException {
        return Files.lines(profileFile).
                map(ProfileEntity::fromString).
                filter(profile -> !profile.getUuid().equals(UUID.fromString(uuid))).
                collect(Collectors.toList());
    }

    public ProfileEntity removeByUuid(String uuid) {
        ProfileEntity res = null;
        try {
            res = getProfileByUuid(uuid);
            if (res != null) {
                Utils.saveAll(profileFile, getAllProfileWithOut(uuid));
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return res;
    }

    public boolean updateByUuid(String uuid, String name, String lastName, String phone) {
        try {
            List<ProfileEntity> curr = getAllProfileWithOut(uuid);
            curr.add(ProfileEntity.fromString(uuid + "," + name + "," + lastName + "," + phone));
            Utils.saveAll(profileFile, curr);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    //CRUD Users

    public boolean addUser(String email, String password, Role role, String profileUuid) throws IOException {
        if (getProfileByUuid(profileUuid) == null) {
            profileUuid = null;
        }
        UserEntity curr = UserEntity.of(email, password, role, profileUuid);
        Utils.save(userFile, curr.toString());
        return true;
    }

    public boolean addUser(UserEntity userEntity) {
        Objects.requireNonNull(userEntity);
        return Utils.save(userFile, userEntity.toString());
    }

    public List<UserEntity> getAllUsers() throws IOException {
        return Files.lines(userFile).
                map(UserEntity::fromString).
                collect(Collectors.toList());
    }

    private List<UserEntity> getAllUserWithOut(String email) throws IOException {
        return Files.lines(userFile).
                map(UserEntity::fromString).
                filter(user -> !user.getEmail().equals(email)).
                collect(Collectors.toList());
    }

    public UserEntity getUserByEmail(String email) throws IOException {
        return Files.lines(userFile).
                map(UserEntity::fromString).
                filter(user -> user.getEmail().equals(email)).
                findFirst().orElse(null);
    }

    public UserEntity getUserByProfileUuid(String uuid) throws IOException {
        return Files.lines(userFile).
                map(UserEntity::fromString).
                filter(user -> user.getProfileUuid().equals(uuid)).
                findFirst().orElse(null);
    }

    public UserEntity removeByEmail(String email) throws IOException {
        UserEntity res = getUserByEmail(email);
        if (res != null) {
            Utils.saveAll(userFile, getAllUserWithOut(email));
        }
        return res;
    }

    public boolean updateUserByEmail(String email, String password, Role role, String profileUuid) {
        try {
            UserEntity curr = getUserByEmail(email);
            if (curr != null) {
                List<UserEntity> userList = getAllUserWithOut(email);
//                if(getProfileByUuid(profileUuid) == null) {
//                    profileUuid = curr.getProfileUuid();
//                }
                userList.add(UserEntity.fromString(email + "," + password + "," + role + "," + profileUuid));
                return Utils.saveAll(userFile, userList);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }
}
