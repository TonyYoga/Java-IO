package com.telran.data.entity;

import java.util.Objects;

public class UserEntity {
    private String email;
    private String password;
    private Role role;
    private String profileUuid;

    private UserEntity(String email, String password, Role role, String profileUuid) {
        this.email = email;
        this.password = password;
        this.role = role;
        this.profileUuid = profileUuid;
    }




    public static UserEntity of(String email, String password, Role role, String profileUuid) {
        //TODO need to do builder
        Objects.requireNonNull(email);
        Objects.requireNonNull(password);
        Objects.requireNonNull(role);
        return new UserEntity(email, password, role, profileUuid);
    }

    public static UserEntity fromString(String user) {
        Objects.requireNonNull(user);
        String[] arr = user.trim().split(",");
        if(arr.length != 4) {
            throw new IllegalArgumentException("Wrong data format");
        }
        return new UserEntity(arr[0], arr[1], Role.valueOf(arr[2]), arr[3]);
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public Role getRole() {
        return role;
    }

    public String getProfileUuid() {
        return profileUuid;
    }

    @Override
    public String toString() {
        return email + "," + password + "," + role + "," + profileUuid;
    }
}
