package com.telran.data.entity;

public enum Role {
    ADMIN, USER
}
