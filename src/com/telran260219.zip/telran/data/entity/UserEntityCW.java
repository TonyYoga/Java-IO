package com.telran.data.entity;

import java.util.Objects;

public class UserEntityCW {
    private String email;
    private String password;
    private Role role;
    private String profileUuid;

    private UserEntityCW(String email, String password, Role role) {
        this.email = email;
        this.password = password;
        this.role = role;
    }

    private UserEntityCW(String email, String password, Role role, String profileUuid) {
        this.email = email;
        this.password = password;
        this.role = role;
        this.profileUuid = profileUuid;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public Role getRole() {
        return role;
    }

    public String getProfileUuid() {
        return profileUuid;
    }

    @Override
    public String toString() {
        return email + "," + password + "," + role + "," + profileUuid;
    }

    public static UserEntityCW of(String email, String password, Role role) {
        return new UserEntityCW(email, password, role);
    }

    public static UserEntityCW of(String email, String password, Role role, String profileUuid) {
        return new UserEntityCW(email, password, role, profileUuid);
    }

    public static UserEntityCW fromString(String data) {
        Objects.requireNonNull(data);
        String[] arr = data.split(",");
        if (arr.length != 4) {
            throw new IllegalArgumentException("Wrong data format!");
        }
        return new UserEntityCW(arr[0], arr[1], Role.valueOf(arr[2]), arr[3]);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserEntityCW that = (UserEntityCW) o;

        return email != null ? email.equals(that.email) : that.email == null;
    }

    @Override
    public int hashCode() {
        return email != null ? email.hashCode() : 0;
    }
}
