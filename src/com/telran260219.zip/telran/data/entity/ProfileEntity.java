package com.telran.data.entity;

import java.util.Objects;
import java.util.UUID;

public class ProfileEntity {
    private UUID uuid;
    private  String name;
    private String lastName;
    private String phone;

    private ProfileEntity(String name, String lastName, String phone) {
        uuid = UUID.randomUUID();
        this.name = name;
        this.lastName = lastName;
        this.phone = phone;
    }

    public ProfileEntity(String uuid, String name, String lastName, String phone) {
        this.uuid = UUID.fromString(uuid);
        this.name = name;
        this.lastName = lastName;
        this.phone = phone;
    }

    public static ProfileEntity of(String name, String lastName, String phone) {
        Objects.requireNonNull(name);
        Objects.requireNonNull(lastName);
        Objects.requireNonNull(phone);
        return new ProfileEntity(name, lastName, phone);
    }

    public static ProfileEntity fromString(String profile) {
        Objects.requireNonNull(profile);
        String[] arr = profile.trim().split(",");
        if (arr.length != 4) {
            throw new IllegalArgumentException("Wrong data format");
        }
        return new ProfileEntity(arr[0], arr[1], arr[2], arr[3]);
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    @Override
    public String toString() {
        return uuid + "," + name + "," + lastName + "," + phone;
    }
}
