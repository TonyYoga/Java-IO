package com.telran.data.entity;

import java.util.Objects;
import java.util.UUID;

public class CategoryEntity {
    private final UUID uuid;
    private final String name;

    private CategoryEntity(String name) {
        this.name = name;
        uuid = UUID.randomUUID();
    }

    private CategoryEntity(String uuid, String name) {
        this.uuid = UUID.fromString(uuid);
        this.name = name;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return uuid.toString() + "," + name;
    }

    public static CategoryEntity of(String name) {
        Objects.requireNonNull(name);
        return new CategoryEntity(name);
    }

    public static CategoryEntity fromString(String data) {
        Objects.requireNonNull(data);
        String[] arr = data.split(",");
        if (arr.length != 2) {
            throw new IllegalArgumentException("Wrong data format!");
        }
        return new CategoryEntity(arr[0], arr[1]);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CategoryEntity that = (CategoryEntity) o;

        return uuid.equals(that.uuid);
    }

}
