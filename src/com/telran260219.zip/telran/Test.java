package com.telran;

import com.telran.controllers.UserControllerCW;
import com.telran.controllers.UserControllerImpl;
import com.telran.controllers.UserControllerImplCW;
import com.telran.data.entity.managers.CatalogManager;
import com.telran.data.entity.managers.UserManager;
import com.telran.data.entity.managers.UserManagerCW;

import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {
        UserControllerCW userControllerCW = new UserControllerImplCW(new UserManagerCW("db", "users.csv", "profile.csv"));
        CatalogManager manager = new CatalogManager("db", "cat.csv", "cities.csv");
//        manager.addCity(CityEntity.of("Ashdod"));
//        manager.addCity(CityEntity.of("Haifa"));
//        manager.addCity(CityEntity.of("Tel Aviv"));
//        manager.addCity(CityEntity.of("Ramla"));
//        manager.removeCityByUuid("d6b6a955-ceb4-491a-9eb8-83b323a4194b");
//        manager.updateCity("b73f4538-40aa-4f45-bde1-ead49abad294", "Toronto");

//        manager.addCategory("Tools1");
//        manager.addCategory("Toyes2");
//        manager.addCategory("Goods3");
//        manager.addCategory("Drinks4");
//        manager.removeCategoryByUuid("1f2415c7-a836-417e-b539-a81da9d6cd48");
//        manager.updateCategory("8de6b870-503a-4f40-a988-b42846fb3280", "Shoes");
//        manager.getAllCities().forEach(System.out::println);
        UserManager userManager = new UserManager("db", "users.csv", "profiles.csv");
//        userManager.addUser(UserEntity.of("admin@shop.com", "000000", Role.ADMIN, null));
//        userManager.addUser(UserEntity.of("userFirst@shop.com", "111111", Role.USER, null));
//        userManager.addUser(UserEntity.of("userSecond@shop.com", "222222", Role.USER, null));

        UserControllerImpl userController = new UserControllerImpl(userManager);
//        userController.changePassword("admin@shop.com", "000000", "newpassword");
//        userController.changePasswordForUser("admin@shop.com", "userFirst@shop.com", "new");
//        userController.removeUser("admin@shop.com", "userSecond@shop.com");

//        ProfileEntity profile = ProfileEntity.of("name", "lastName", "911");
//        userController.updateProfile("userFirst@shop.com", profile);
        userController.removeProfileById("admin@shop.com","25d0bd80-aaa0-400f-9d4c-778de2d56bfa");
    }
}
