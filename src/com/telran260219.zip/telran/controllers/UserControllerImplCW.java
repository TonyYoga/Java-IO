package com.telran.controllers;

import com.telran.data.entity.*;
import com.telran.data.entity.managers.UserManagerCW;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class UserControllerImplCW implements UserControllerCW {
    private UserManagerCW manager;

    public UserControllerImplCW(UserManagerCW manager) {
        this.manager = manager;
    }

    @Override
    public boolean changePassword(String email, String oldPassword, String newPassword) {
        return false;
    }

    @Override
    public boolean changePasswordForUser(String adminEmail, String userEmail, String newPassword) {
        return false;
    }

    @Override
    public List<UserEntityCW> getAllUsers(String adminEmail) {
        if (isAdmin(adminEmail)) {
            try {
                return manager.getAllUsers();
            } catch (IOException e) {
                e.printStackTrace();
                return Collections.emptyList();
            }
        }
        return Collections.emptyList();
    }

    @Override
    public boolean addUser(String adminEmail, UserEntityCW user) {
        Objects.requireNonNull(user);
        Objects.requireNonNull(adminEmail);
        if (isAdmin(adminEmail)) {
            ProfileEntityCW empty = new ProfileEntityCW.Builder().build();
            try {
                manager.addProfile(empty);
                UserEntityCW forSave = UserEntityCW.of(user.getEmail(),
                        user.getPassword(),
                        user.getRole(),
                        empty.getUuid());
                manager.addUser(forSave);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public UserEntityCW removeUser(String adminEmail, String userEmail) {
        return null;
    }

    @Override
    public boolean updateProfile(String email, ProfileEntityCW profileEntity) {
        return false;
    }

    @Override
    public ProfileEntityCW removeProfileById(String adminEmail, String profileUuid) {
        return null;
    }

    @Override
    public ProfileEntityCW getProfileById(String adminEmail, String profileUuid) {
        return null;
    }

    private boolean isAdmin(String email) {
        Objects.requireNonNull(email);
        try {
            UserEntityCW user = manager.getUserByEmail(email);
            if (user.getRole().equals(Role.ADMIN)) {
                return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
