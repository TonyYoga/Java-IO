package com.telran.controllers;

import com.telran.data.entity.ProfileEntity;
import com.telran.data.entity.UserEntity;

import java.util.List;

public interface UserController {
    /**
     * Меняет пароль у юзера. Соответствующая проверка старого пароля
     * @param email
     * @param oldPassword
     * @param newPassword
     * @return
     */
    boolean changePassword(String email, String oldPassword, String newPassword);

    /**
     * Метод для админа, провека юзера на администратора
     * @param adminEmail
     * @param userEmail
     * @param newPassword
     * @return
     */
    boolean changePasswordForUser(String adminEmail, String userEmail, String newPassword);

    /**
     * Доступ только для админа
     * @param adminEmail
     * @return
     */
    List<UserEntity> getAllUsers(String adminEmail);

    /**
     * только для админа
     * @param adminEmail
     * @param userEntity
     * @return
     */
    boolean addUser(String adminEmail, UserEntity userEntity);

    /**
     * только для админа
     * @param adminEmail
     * @param userEmail
     * @return deleted userEntity
     */
    UserEntity removeUser(String adminEmail, String userEmail);

    /**
     * If email equals profileEntity - email = That means that user update own profile.
     * If email = adminEmail - That means that admin updating user profile
     * @param email
     * @param profileEntity
     * @return
     */
    boolean updateProfile(String email, ProfileEntity profileEntity);

    /**
     * Удаление профайла по ИД
     * @param adminEmail
     * @param profileUuid
     * @return
     */
    ProfileEntity removeProfileById(String adminEmail, String profileUuid);

    /**
     * Получить профайл по ИД
     * @param adminEmail
     * @param profileUuid
     * @return
     */
    ProfileEntity getProfileById(String adminEmail, String profileUuid);
}
