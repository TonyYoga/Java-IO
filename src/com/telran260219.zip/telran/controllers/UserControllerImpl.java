package com.telran.controllers;

import com.telran.data.entity.ProfileEntity;
import com.telran.data.entity.Role;
import com.telran.data.entity.UserEntity;
import com.telran.data.entity.managers.UserManager;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

public class UserControllerImpl implements UserController{
    private UserManager manager;

    public UserControllerImpl(UserManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean changePassword(String email, String oldPassword, String newPassword) {
        try {
            UserEntity curr = manager.getUserByEmail(email);
            if (curr != null && curr.getPassword().equals(oldPassword)) {
                return manager.updateUserByEmail(email, newPassword, curr.getRole(), curr.getProfileUuid());
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    @Override
    public boolean changePasswordForUser(String adminEmail, String userEmail, String newPassword) {
        try {
            UserEntity curr = manager.getUserByEmail(userEmail);
            if (!isAdmin(adminEmail) || curr == null) {
                return false;
            }
            return changePassword(userEmail, curr.getPassword(), newPassword);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<UserEntity> getAllUsers(String adminEmail) {
        try {
            if (isAdmin(adminEmail)) {
                return manager.getAllUsers();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean addUser(String adminEmail, UserEntity userEntity) {
        try {
            if (isAdmin(adminEmail))
            return manager.addUser(userEntity);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public UserEntity removeUser(String adminEmail, String userEmail) {
        try {
            if (isAdmin(adminEmail)) {
                return manager.removeByEmail(userEmail);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean updateProfile(String email, ProfileEntity profileEntity) {
        try {
            UserEntity currUser = manager.removeByEmail(email);
            Objects.requireNonNull(profileEntity);
            ProfileEntity currProf = manager.getProfileByUuid(profileEntity.getUuid().toString());
            if (currUser != null && currUser.getEmail().equals(email) && currProf == null) {
                manager.addProfile(profileEntity);
                return manager.addUser(currUser.getEmail(),
                            currUser.getPassword(),
                            currUser.getRole(),
                            profileEntity.getUuid().toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public ProfileEntity removeProfileById(String adminEmail, String profileUuid) {
        try {
            if (isAdmin(adminEmail)) {
                ProfileEntity currProfile = manager.removeByUuid(profileUuid);
                if (currProfile != null) {
                    UserEntity curr = manager.getUserByProfileUuid(profileUuid);
                    manager.updateUserByEmail(curr.getEmail(), curr.getPassword(), curr.getRole(), null);
                }
                return currProfile;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public ProfileEntity getProfileById(String adminEmail, String profileUuid) {
        try {
            if (isAdmin(adminEmail)) {
                return manager.getProfileByUuid(profileUuid);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private boolean isAdmin(String adminEmail) throws IOException {
        UserEntity admin = manager.getUserByEmail(adminEmail);
        if (admin == null || !admin.getRole().equals(Role.ADMIN)) {
            return false;
        }
        return true;
    }
}
