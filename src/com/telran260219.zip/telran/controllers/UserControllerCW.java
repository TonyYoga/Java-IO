package com.telran.controllers;

import com.telran.data.entity.ProfileEntityCW;
import com.telran.data.entity.UserEntityCW;

import java.util.List;

public interface UserControllerCW {

    /**
     * Меняет пароль у юзера. Соответствующая проверка старого пароля
     * @param email
     * @param oldPassword
     * @param newPassword
     * @return
     */
    boolean changePassword(String email, String oldPassword, String newPassword);

    /**
     * Метод для админа, провека юзера на администратора
     * @param adminEmail
     * @param userEmail
     * @param newPassword
     * @return
     */
    boolean changePasswordForUser(String adminEmail, String userEmail, String newPassword);

    /**
     * Доступ только для админа
     * @param adminEmail
     * @return
     */
    List<UserEntityCW> getAllUsers(String adminEmail);

    /**
     * только для админа
     * @param adminEmail
     * @param userEntity
     * @return
     */
    boolean addUser(String adminEmail, UserEntityCW userEntity);

    /**
     * только для админа
     * @param adminEmail
     * @param userEmail
     * @return deleted userEntity
     */
    UserEntityCW removeUser(String adminEmail, String userEmail);

    /**
     * If email equals profileEntity - email = That means that user update own profile.
     * If email = adminEmail - That means that admin updating user profile
     * @param email
     * @param profileEntity
     * @return
     */
    boolean updateProfile(String email, ProfileEntityCW profileEntity);

    /**
     * Удаление профайла по ИД
     * @param adminEmail
     * @param profileUuid
     * @return
     */
    ProfileEntityCW removeProfileById(String adminEmail, String profileUuid);

    /**
     * Получить профайл по ИД
     * @param adminEmail
     * @param profileUuid
     * @return
     */
    ProfileEntityCW getProfileById(String adminEmail, String profileUuid);
}
